Trabajo fin de ciclo (TFG): Aplicacion de Reservas de Aparcamiento de Ciudad Escolar (ARACE).
Autores: David Ortiz y Jesus Pedroza.
En este Github, se encuentra todo el trabajo realizado incluyendo la memoria y un manual de usuario.
También la aplicacion esta subida a Uptodown: https://arace.uptodown.com/android (Nota: puede que la versión de la app no corresponda con la actual del repositorio eso debe ser por que a veces suele tardar en publicarse la ultima version)
